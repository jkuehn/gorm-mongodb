@artifact.package@import grails.plugins.mongodb.MongoEntity

@MongoEntity
class @artifact.name@ {

    static constraints = {
    }
}
