@artifact.package@import com.google.code.morphia.annotations.Entity
import com.google.code.morphia.utils.AbstractMongoEntity

@Entity
class @artifact.name@ extends AbstractMongoEntity {

    static constraints = {
    }
}
